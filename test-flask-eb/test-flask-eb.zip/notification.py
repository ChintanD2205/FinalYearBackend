import firebase_admin
from firebase_admin import credentials, messaging
from flask import request

# Send Push Notification
def send_push_notification():
    try:
        # Construct message
        message = messaging.Message(
            notification=messaging.Notification(
                title=request.json["title"],
                body=request.json["body"]
            ),
            token=request.json["fcm_token"]
        )

        # Send message
        response = messaging.send(message)

        return {"message": "Notification Sent"}, 200
    except Exception as e:
        return {"message": str(e)}, 500
