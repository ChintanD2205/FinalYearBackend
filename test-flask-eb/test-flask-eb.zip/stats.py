from flask import Flask, render_template
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import io
import base64

def gen_stats(width_px, height_px):
    x = np.linspace(0, 10, 100)
    y1 = np.sin(x)
    y2 = np.cos(x)
    colors = np.sin(x) + np.cos(x)

    # Convert pixels to inches
    dpi = 100  # Adjust DPI as needed
    width_inches = width_px / dpi
    height_inches = height_px / dpi

    # Create the Matplotlib plot with adjusted figure size
    fig, ax = plt.subplots(figsize=(width_inches, height_inches))
    ax.scatter(x, y1, c=colors, cmap='hsv', label='sin(x)')
    ax.scatter(x, y2, c=colors, cmap='hsv', marker='^', label='cos(x)')
    ax.set_title('Vibrant Visualization with Matplotlib')
    ax.set_xlabel('X-axis')
    ax.set_ylabel('Y-axis')
    ax.legend()
    ax.grid(True)

    # Convert the plot to base64-encoded image data
    img = io.BytesIO()
    fig.savefig(img, format='png', dpi=dpi)
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.close(fig)

    return render_template('index.html', plot_url=plot_url)

