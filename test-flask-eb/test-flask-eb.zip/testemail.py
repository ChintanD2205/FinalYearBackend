import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import random

def generate_otp():
    return random.randint(100000, 999999)
def send_email(receiver_email):
    # Set up the SMTP server
    otp = generate_otp()
    sender_email = 'chintan222005@gmail.com'
    sender_password = 'iwuz nuqp szcw dtfr'
    subject = 'Test Email'
    message = f'This is a test email sent from Python. \n Your Otp is {otp}'
    smtp_server = smtplib.SMTP('smtp.gmail.com', 587)
    smtp_server.starttls()
    
    # Log in to the SMTP server
    smtp_server.login(sender_email, sender_password)
    
    # Create a MIMEMultipart object
    email_message = MIMEMultipart()
    email_message['From'] = sender_email
    email_message['To'] = receiver_email
    email_message['Subject'] = subject
    
    # Attach the message to the email
    email_message.attach(MIMEText(message, 'plain'))
    
    # Send the email
    smtp_server.send_message(email_message)
    
    # Close the SMTP server
    smtp_server.quit()
    return otp
"""
# Example usage
sender_email = 'chintan222005@gmail.com'
sender_password = 'iwuz nuqp szcw dtfr'
receiver_email = 'chintan222005@gmail.com'
subject = 'Test Email'
message = f'This is a test email sent from Python. \n Your Otp is {generate_otp()}'

send_email(sender_email, sender_password, receiver_email, subject, message)
"""