import cv2 as cv

def verify_human_face(image_path):
    # Load the Haar Cascade classifier for face detection
    face_cascade = cv.CascadeClassifier(cv.data.haarcascades + 'haarcascade_frontalface_default.xml')
    
    # Read the uploaded image
    image = cv.imread(image_path)
    
    # Convert the image to grayscale for face detection
    gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
    
    # Detect faces in the image
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
    
    # Check if any faces are detected
    if len(faces) > 0:
        print("Human face(s) detected in the uploaded image.")
        return True
    else:
        print("No human faces detected in the uploaded image.")
        return False

# Example usage
image_path = "Screenshot 2024-03-12 115205.png"  # Replace with the path to the uploaded image
is_human_face = verify_human_face(image_path)
