import requests
from bs4 import BeautifulSoup

def scrape_scholarship_info():
    # Predefined URL of the webpage you want to scrape
    url = "https://scholarships.gov.in/"

    # Send a GET request to the URL
    response = requests.get(url)

    # Check if the request was successful
    if response.status_code == 200:
        # Parse the HTML content of the webpage
        soup = BeautifulSoup(response.content, 'html.parser')

        span_tag = soup.find('span', class_='notification')

        # Check if the content of the span tag is "Notice Board - For Students"
        if span_tag and span_tag.text.strip() == "Notice Board - For Students":
            # If yes, find the <ul> tag inside the second <div>
            ul_tag = soup.select_one('.card-body.notificationbody ul')
            if ul_tag:
                # Extract the text content of all <li> tags
                result = []
                li_tags = ul_tag.find_all('li')
                for li_tag in li_tags:
                    li_text = li_tag.text.strip()
                    links_index = li_text.find("Links")
                    if links_index != -1:
                        # Slice the text content up to the "Links" index
                        li_text = li_text[:links_index]
                    result.append(li_text)
                return result
        else:
            return "Span content does not match."
    else:
        return "Failed to fetch the webpage. Status code:", response.status_code
