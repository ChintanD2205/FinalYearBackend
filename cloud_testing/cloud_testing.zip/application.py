from flask import Flask, request, jsonify
application = Flask(__name__)


@application.route("/", methods=['GET', 'POST'])
def handle_blank():
    return "Hello World"

@application.route("/newUser",  methods=['GET', 'POST'])
def handle_new_user():
    return "Welcome to Vidyavibhava"